import aplicacao.ACMEAirDrones;

public class Main {
    public static void main(String[] args) {
        new ACMEAirDrones().executar();
    }
}