package aplicacao;
import dados.Frota;

public class ACMEAirDrones {

	public void executar() {
		Frota frota = new Frota();
		JanelaCadastroDrone cadastro = new JanelaCadastroDrone(frota);
	}
}
